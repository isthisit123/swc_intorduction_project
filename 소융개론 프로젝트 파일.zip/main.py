import tkinter as tk
import tkinter.messagebox as msgbox
import tkinter.ttk as ttk
import time
import cv2
import dlib
import time
from plyer import notification
from playsound import playsound

# Dlib의 얼굴 감지 모델
detector = dlib.get_frontal_face_detector()

def face(): #얼굴감지
    global r_time
    start_time = time.time()
    L=[]
    cap = cv2.VideoCapture(0)
    r_time=0
    while True:
        
        ret, frame = cap.read()
        if not ret:
            print('프레임읽기실패')
            
        # 흑백 변환 (얼굴 감지를 위해)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # 얼굴 감지
        faces = detector(gray)

        # 감지된 얼굴에 사각형 그리기
        for face in faces:
            x, y, w, h = face.left(), face.top(), face.width(), face.height()
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
        current_time=start_time
        if len(faces)==1:
            current_time=time.time()
        elif len(faces)==0:
            start_time=time.time()

        elapsed_time=current_time-start_time

        dot=str(elapsed_time).find('.')
        aa=str(elapsed_time)[:dot] #elapsed_time의 정수부분만 표시
        
        # print('aa는',aa)
        L.append(aa)
        if aa=='-0': # 얼굴이 보일때부터 가려질때까지 시간 더하기
            b=len(L)
            r_time+=abs(int(L[b-2])) #얼굴이 가려져 aa=='-0'이 될 때 순간적으로 L[b-2]가 음수가 되므로 abs로 양수변환
            L.clear() #리스트 클리어
        elif aa=='30': #30초마다 시간더하기
            r_time+=30
            L.clear() #리스트 클리어
        # print('얼굴인식시간은',r_time)
        if r_time>=time2s*60: #여기에 스트레칭 시간
            print(f'{time2s}분이 지났습니다.')
            r_time=0 #시간초기화
            break

        # 체크박스 값에 따라 프레임을 화면에 표시
        if var_c.get()==1:
            cv2.imshow('Face Detection', frame)
        
        # 'q' 키를 누르면 루프 종료
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # 웹캠 해제 및 윈도우 종료
    cap.release()
    cv2.destroyAllWindows()

    #알림함수로 이동
    alarm111()

def alarm111(): #알림함수
    if alarm_type==2: #윈도우 알림을 선택할 경우
        notification.notify(
            title='스트레칭 알림',
            message='스트레칭 시간입니다.',
            timeout=10,
        )
    else: # tts 알림을 선택한 경우
        # 절대경로를 썼기 때문에 사용시 경로 바꿔서 사용
        for p in Ls:
            if p=='back':
                playsound(r'C:\\Users\\jhh\\OneDrive\\바탕 화면\\g_project\back_neck.mp3')
            elif p=='front':
                playsound(r'C:\\Users\\jhh\\OneDrive\\바탕 화면\\g_project\\front_neck.mp3')
            elif p=='muscle':
                playsound(r'C:\\Users\\jhh\\OneDrive\\바탕 화면\\g_project\\muscle.mp3')
            elif p=='shoulder':
                playsound(r'C:\\Users\\jhh\\OneDrive\\바탕 화면\\g_project\\shoulder.mp3')

    msgbox.showinfo("알림","잠시뒤 프로그램이 자동실행됩니다\n종료하시려면 '프로그램종료'를 눌러주세요.")
    response1=msgbox.askokcancel('확인/취소','프로그램을 계속 진행시키겠습니까?')

    if response1==1: #계속 진행하면 face()함수 실행
        face()
    elif response1==0: #취소 누르면 종료
        close_window

def fr1_fr2(): #1페이지 확인버튼
    if chkvar.get()==1:
        frame1.pack_forget()
        frame2.pack()
    else:
        msgbox.showwarning("경고","체크해주세요.")


def fr2_fr3(): #2페이지 확인버튼
    global time2s
    time1=cbx.get()
    if time1[:-1].isdigit()==True:
        frame2.pack_forget()
        frame3.pack()
        time2s=int(time1[:-1]) #time2s에 스트레칭시간 저장
    else:
        msgbox.showwarning("경고","시간을 선택해주세요.")

def fr3_fr4(): #3페이지 확인버튼
    global Ls
    back=var1.get()
    front=var2.get()
    muscle=var3.get()
    shoulder=var4.get()
    Ls=[] #스트레칭할 것을 Ls에 저장
    d={'back':back,'front':front,'muscle':muscle,'shoulder':shoulder}
    for i in d:
        if d[i]==1:
            Ls.append(i)
    if len(Ls)!=0:
        frame3.pack_forget()
        frame4.pack()
    else:
        msgbox.showwarning("경고","하고 싶은 스트레칭을 선택해주세요")

def fr4_fin(): #4페이지 확인버튼
    global alarm_type
    alarm_type=alarm.get()
    if alarm.get()==1 or 2:
        msgbox.showinfo("알림","설정이 완료되었습니다.\n잠시후 창이 닫힙니다.")
        time.sleep(1)
        close_window()
    else:
        msgbox.showwarning("경고","알림 방식을 선택해주세요")

def btn_cmd():
    btn.config(text="프로그램 종료",command=close_pro) #텍스트, 코맨드 변경
    face()
    
def close_pro():
    response=msgbox.askokcancel("프로그램 종료","프로그램을 정말 종료하시겠습니까?")
    if response:
        close_window()

def close_window(): #프로그램종료
    root.destroy()

try: #이전 설정값 불러오기
    f=open('setting.txt','r')
    contents=f.read()
    read_time=contents[1:3]
    read_alarm=contents[-2]
    read_camera=contents[-1]

    root=tk.Tk()
    root.title("설정")

    frame1=tk.Frame(root)
    frame2=tk.Frame(root)
    frame3=tk.Frame(root)
    frame4=tk.Frame(root)
    frame5=tk.Frame(root)

    #1페이지 (체크박스를 이용하여 내장캠만 이용가능확인)
    chkvar=tk.IntVar()
    chkbtn1=tk.Checkbutton(frame1,text="이 프로그램은 내장캠만 이용가능합니다.",variable=chkvar)
    btn1=tk.Button(frame1,text="확인",command=fr1_fr2)
    chkbtn1.pack()
    btn1.pack()
    chkbtn1.select()

    #2페이지 (콤보박스를 이용하여 10분에서 40분 중에 원하는 스트레칭 주기 선택창)
    L1=[str(i)+"분" for i in range(10,41)] 
    label_2p=tk.Label(frame2,text="몇 분마다 스트레칭하시겠습니까?")
    label_2p.pack()
    cbx=ttk.Combobox(frame2,height=5,values=L1)
    cbx.set("시간을 선택해주세요")
    cbx.pack()
    btn2=tk.Button(frame2,text="확인",command=fr2_fr3)
    btn2.pack()
    cbx.set(f"{read_time}"+"분")

    #3페이지 (4가지 스트레칭 중 원하는 것 선택하도록 체크박스창)
    label_3p=tk.Label(frame3,text="어떤 스트레칭을 하시겠습니까?")
    label_3p.pack()
    var1=tk.IntVar()
    var2=tk.IntVar()
    var3=tk.IntVar()
    var4=tk.IntVar()
    chb1=tk.Checkbutton(frame3,text="뒷목 스트레칭",variable=var1)
    chb2=tk.Checkbutton(frame3,text="앞목 스트레칭",variable=var2)
    chb3=tk.Checkbutton(frame3,text="승모근 스트레칭",variable=var3)
    chb4=tk.Checkbutton(frame3,text="어깨 스트레칭",variable=var4)
    chb1.pack()
    chb2.pack()
    chb3.pack()
    chb4.pack()
    btn3=tk.Button(frame3,text="확인",command=fr3_fr4)
    btn3.pack()

    if 'back' in contents:
        chb1.select()
    if 'front' in contents:
        chb2.select()
    if 'muscle' in contents:
        chb3.select()
    if 'shoulder' in contents:
        chb4.select()

    #4페이지 (2가지 알림 방식 중 선택하도록 라디오버튼 창)
    label_4p=tk.Label(frame4,text="어떤 방식으로 스트레칭 알림을 받으시겠습니까?")
    label_4p.pack()
    alarm=tk.IntVar()
    rdb1=tk.Radiobutton(frame4,text="tts로 알림받기",value=1,variable=alarm)
    rdb2=tk.Radiobutton(frame4,text="윈도우 알림 띄우기",value=2,variable=alarm)
    rdb1.pack()
    rdb2.pack()
    btn4=tk.Button(frame4,text="확인",command=fr4_fin)
    btn4.pack()

    if read_alarm=='1':
        rdb1.select()
    elif read_alarm=='2':
        rdb2.select()

    frame1.pack()
    root.mainloop()

    # 스트레칭 목록을 string으로 만들기
    strech=""
    for i in Ls:
        if i=="back":
            strech+="뒷목 스트레칭 "
        elif i=="fornt":
            strech+="앞목 스트레칭 "
        elif i=="muscle":
            strech+="승모근 스트레칭 "
        elif i=="shoulder":
            strech+="어깨 스트레칭 "
    strech=strech.strip() #strech에 빈칸 없애기

    # 알림
    if alarm_type==1:
        alarm="tts 알림"
    elif alarm_type==2:
        alarm="윈도우 알림"

    # 프로그램 실행 페이지   
    root=tk.Tk()
    root.title("프로그램 작동중")
    label=tk.Label(root,text=f"{time2s}분마다 {strech}을\n{alarm}으로 알려드립니다.") #설정값을 보여줌
    label.pack()
    btn=tk.Button(root,text="프로그램시작",command=btn_cmd)
    btn.pack()
    var_c=tk.IntVar()
    chb5=tk.Checkbutton(root,text="카메라 on",variable=var_c) #카메라 끄고 키기
    chb5.pack()

    if read_camera=='1':
        chb5.select()

    root.mainloop()

    #설정값을 setting.txt파일에 저장
    f=open('setting.txt','wt')
    f.write(str(chkvar.get()))
    f.write(str(time2s))
    f.write(str(Ls))
    f.write(str(alarm_type))
    f.write(str(var_c.get()))
    f.close()

except: #프로그램을 처음 실행할 경우 이전 설정값이 없기 때문에 except사용

    root=tk.Tk()
    root.title("설정")

    frame1=tk.Frame(root)
    frame2=tk.Frame(root)
    frame3=tk.Frame(root)
    frame4=tk.Frame(root)
    frame5=tk.Frame(root)

    #1페이지 
    chkvar=tk.IntVar()
    chkbtn1=tk.Checkbutton(frame1,text="이 프로그램은 내장캠만 이용가능합니다.",variable=chkvar)
    btn1=tk.Button(frame1,text="확인",command=fr1_fr2)
    chkbtn1.pack()
    btn1.pack()

    #2페이지
    L1=[str(i)+"분" for i in range(10,41)] 
    label_2p=tk.Label(frame2,text="몇 분마다 스트레칭하시겠습니까?")
    label_2p.pack()
    cbx=ttk.Combobox(frame2,height=5,values=L1)
    cbx.set("시간을 선택해주세요")
    cbx.pack()
    btn2=tk.Button(frame2,text="확인",command=fr2_fr3)
    btn2.pack()

    #3페이지
    label_3p=tk.Label(frame3,text="어떤 스트레칭을 하시겠습니까?")
    label_3p.pack()
    var1=tk.IntVar()
    var2=tk.IntVar()
    var3=tk.IntVar()
    var4=tk.IntVar()
    chb1=tk.Checkbutton(frame3,text="뒷목 스트레칭",variable=var1)
    chb2=tk.Checkbutton(frame3,text="앞목 스트레칭",variable=var2)
    chb3=tk.Checkbutton(frame3,text="승모근 스트레칭",variable=var3)
    chb4=tk.Checkbutton(frame3,text="어깨 스트레칭",variable=var4)
    chb1.pack()
    chb2.pack()
    chb3.pack()
    chb4.pack()
    btn3=tk.Button(frame3,text="확인",command=fr3_fr4)
    btn3.pack()

    #4페이지
    label_4p=tk.Label(frame4,text="어떤 방식으로 스트레칭 알림을 받으시겠습니까?")
    label_4p.pack()
    alarm=tk.IntVar()
    rdb1=tk.Radiobutton(frame4,text="tts로 알림받기",value=1,variable=alarm)
    rdb2=tk.Radiobutton(frame4,text="윈도우 알림 띄우기",value=2,variable=alarm)
    rdb1.pack()
    rdb2.pack()
    btn4=tk.Button(frame4,text="확인",command=fr4_fin)
    btn4.pack()

    frame1.pack()
    root.mainloop()

    # 스트레칭 목록을 string으로 만들기
    strech=""
    for i in Ls:
        if i=="back":
            strech+="뒷목 스트레칭 "
        elif i=="fornt":
            strech+="앞목 스트레칭 "
        elif i=="muscle":
            strech+="승모근 스트레칭 "
        elif i=="shoulder":
            strech+="어깨 스트레칭 "
    strech=strech.strip()

    # 알림
    if alarm_type==1:
        alarm="tts 알림"
    elif alarm_type==2:
        alarm="윈도우 알림"

    # 프로그램 실행 페이지   
    root=tk.Tk()
    root.title("프로그램 작동중")
    label=tk.Label(root,text=f"{time2s}분마다 {strech}을\n{alarm}으로 알려드립니다.")
    label.pack()
    btn=tk.Button(root,text="프로그램시작",command=btn_cmd)
    btn.pack()
    var_c=tk.IntVar()
    chb5=tk.Checkbutton(root,text="카메라 on",variable=var_c) #카메라 끄고 키기
    chb5.pack()
    root.mainloop()

    #설정값을 setting.txt에 저장, 다음실행부터는 setting.txt값을 불러옴
    f=open('setting.txt','wt')
    f.write(str(chkvar.get()))
    f.write(str(time2s))
    f.write(str(Ls))
    f.write(str(alarm_type))
    f.write(str(var_c.get()))
    f.close()