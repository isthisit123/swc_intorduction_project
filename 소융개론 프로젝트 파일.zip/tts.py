from gtts import gTTS
import os

def text_to_speech(text, language='en'):
    # gTTS 객체 생성
    tts = gTTS(text=text, lang=language, slow=True)

    # 음성 파일 저장
    tts.save("output.mp3")

if __name__ == "__main__":
    text = '''문자를 입력하세요.'''
    text_to_speech(text, language='ko')
