from pydub import AudioSegment

def merge_mp3_files(file1, file2, output_file):
    # MP3 파일을 불러옵니다.
    sound1 = AudioSegment.from_mp3(file1)
    sound2 = AudioSegment.from_mp3(file2)

    # 두 음악 파일을 합칩니다.
    combined_sound = sound1 + sound2

    # 합쳐진 음악을 새로운 파일로 내보냅니다.
    combined_sound.export(output_file, format="mp3")
    print(f"MP3 files {file1} and {file2} have been merged successfully to {output_file}")

# 사용 예시
file1_path = "input1.mp3"
file2_path = "input2.mp3"
output_file_path = "output.mp3"

merge_mp3_files(file1_path, file2_path, output_file_path)
